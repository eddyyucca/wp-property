<?php
/**
 * Template Name: Works list
 * It is used to make Works list page, that list all works
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

get_template_part( 'works-list' );